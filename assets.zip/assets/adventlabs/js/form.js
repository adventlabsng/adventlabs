let loginForm = document.getElementById('getInTouchForm');

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();

  let name = document.getElementById('name');
  let company = document.getElementById('company');
  let email = document.getElementById('email');
  let phone = document.getElementById('phone');
  let description = document.getElementById('description');

  if (name.value === '' || email.value === '' || phone.value === '') {
    alert('Ensure you input a value in all fields!');
  } else {
    const payload = {
      text: `${name} from ${company} left a message`,
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `${description}`,
          },
        },
        {
          type: 'section',
          block_id: 'section567',
          text: {
            type: 'mrkdwn',
            text: `${phone} \n ${email}`,
          },
        },
        {
          type: 'section',
          block_id: 'section789',
          fields: [
            {
              type: 'mrkdwn',
              text: `${name} from ${company}`,
            },
          ],
        },
      ],
    };
    fetch(
      'https://hooks.slack.com/services/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',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
        credentials: 'same-origin',
      }
    )
      .then((data) => {
        if (!data) {
          throw Error(data.status);
        }
        return data.json();
      })
      .then(() => {
        alert('We have received you data and we will get in touch');
      });
    console.log(
      `This form has a username of ${name.value} and password of ${email.value}`
    );

    name.value = '';
    company.value = '';
    email.value = '';
    phone.value = '';
    description.value = ';';
  }
});
